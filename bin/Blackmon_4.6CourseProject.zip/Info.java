/*************************************************************************
 * Name: Kevin Blackmon
 * Date: 4.21.2024
 * Assignment: Final Project
 * 
 * The interface class that abstracts the two generate methods.
 */

public interface Info {
    public String generateInfo();
}
